export default function EditFood(){
    return <div className="bg-red">

    </div>
}